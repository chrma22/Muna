(() => {
  const state = {
    data: [],
    filter: 'alle',
    query: '',
    selectedId: null
  };

  const el = sel => document.querySelector(sel);
  const els = sel => Array.from(document.querySelectorAll(sel));

  function fmtCount(n){
    return `${n} Eintrag${n===1?'':'e'}`;
  }

  async function load(){
    const res = await fetch('data/items.json');
    state.data = await res.json();
    renderList();
    // Select first item
    if(state.data.length){
      select(state.data[0].id);
    }
  }

  function renderList(){
    const list = el('#itemList');
    list.innerHTML = '';
    const items = filtered();
    items.forEach(it => {
      const row = document.getElementById('itemRowTpl').content.cloneNode(true);
      const btn = row.querySelector('.row');
      btn.dataset.id = it.id;
      row.querySelector('.row-title').textContent = it.title;
      row.querySelector('.row-sub').textContent = `${it.category} • ${it.country || 'Unbekannt'}`;
      btn.addEventListener('click', () => select(it.id));
      list.appendChild(row);
    });
    el('#countBadge').textContent = fmtCount(items.length);
  }

  function filtered(){
    const q = state.query.trim().toLowerCase();
    return state.data.filter(it => {
      const matchesFilter = state.filter === 'alle' || it.category === state.filter;
      if(!matchesFilter) return false;
      if(!q) return true;
      return [it.title, it.category, it.tags?.join(' ') || '', it.details?.material || '']
        .join(' ').toLowerCase().includes(q);
    });
  }

  function select(id){
    state.selectedId = id;
    const it = state.data.find(x => x.id === id);
    if(!it) return;
    const view = el('#detailView');
    view.setAttribute('aria-busy','false');
    view.innerHTML = `
      <div class="card">
        <h2>${it.title}</h2>
        <ul class="desc">
          ${it.description.map(p => `<li>${p}</li>`).join('')}
        </ul>
      </div>
      <div class="side">
        <figure>${it.image ? `<img src="${it.image}" alt="${it.title}">` : '<div class="ph">Kein Bild</div>'}</figure>
        <div class="card specs">
          <dl>
            ${Object.entries(it.details || {}).map(([k,v]) => `
              <dt>${k}</dt>
              <dd>${v}</dd>
            `).join('')}
          </dl>
        </div>
      </div>
    `;
  }

  // Wire up search
  el('#searchInput').addEventListener('input', (e) => {
    state.query = e.target.value;
    renderList();
  });

  // Wire up filters
  els('.nav-link').forEach(btn => {
    btn.addEventListener('click', () => {
      els('.nav-link').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.filter = btn.dataset.filter;
      renderList();
    });
  });

  // Placeholder actions
  el('#btnFeedback').addEventListener('click', () => alert('Feedback: Schreiben Sie uns an example@example.org'));
  el('#btnFilter').addEventListener('click', () => alert('Filter: Kommt bald – benutzen Sie vorerst die Suche & Kategorien.'));

  load();
})();